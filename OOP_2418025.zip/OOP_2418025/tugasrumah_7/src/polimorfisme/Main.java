package polimorfisme;
public class Main {
    public static void main(String[] args) {
        // Polimorfisme: Menggunakan tipe superclass untuk mereferensikan objek subclass
        BankAccount myAccount = new RekeningTransaksi("1234567890", "anonymous", 5000000.0);

        // Menampilkan informasi rekening
        myAccount.tampilkanInformasiRekening();

        // Transaksi
        myAccount.setor(90000000.0); // Demonstrates method call
        myAccount.tarik(2000000.0);  // Demonstrates method call

        // Menampilkan informasi rekening yang diperbarui
        myAccount.tampilkanInformasiRekening();
    }
}
