package polimorfisme;
public class RekeningTransaksi extends BankAccount {
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal) {
        super(nomorRekening, namaPemilik, saldoAwal);
    }
    @Override
    public void tampilkanInformasiRekening() {
        System.out.println("=== Informasi Rekening ===");
        System.out.println("Nomor Rekening : " + this.nomorRekening);
        System.out.println("Nama Pemilik   : " + this.namaPemilik);
        System.out.println("Saldo          : Rp" + String.format("%,.0f", this.saldo) + ",0");
    }
    @Override
    public void setor(double jumlah) {
        super.setor(jumlah); 
    }
    @Override
    public void tarik(double jumlah) {
        super.tarik(jumlah);
    }
}

