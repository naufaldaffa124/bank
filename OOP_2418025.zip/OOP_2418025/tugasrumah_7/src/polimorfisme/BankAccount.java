package polimorfisme;
public abstract class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;
    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }
    public abstract void tampilkanInformasiRekening();
    public void setor(double jumlah) {
        this.saldo += jumlah;
        System.out.println("Berhasil menyetor: Rp" + String.format("%,.0f", jumlah) + ",0");
    }
    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah;
            System.out.println("Berhasil menarik: Rp" + String.format("%,.0f", jumlah) + ",0");
        } else {
            System.out.println("Saldo tidak mencukupi untuk penarikan sebesar Rp" + String.format("%,.0f", jumlah) + ",0");
        }
    }
}



