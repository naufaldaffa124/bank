/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overrideoverloading;

/**
 *
 * @author 1242004
 */
public class Main {
    public static void main(String[] args) {
        // Objek pertama: Rekening biasa
        BankAccount rekening1 = new BankAccount("1234567890", "anonymous", 5000000.0);
        rekening1.tampilkanInformasiRekening();
        System.out.println(); // Baris kosong untuk pemisah

        // Objek kedua: RekeningTransaksi (inheritance dari Rekening)
        RekeningTransaksi rekening2 = new RekeningTransaksi("1234567890", "anonymous", 5000000.0);
        
        // Memanggil method overloading 'setor'
        rekening2.setor(5000000.0); // Memanggil setor(double jumlah)
        
        // Memanggil method overloading 'tarik'
        rekening2.tarik(1000000.0); // Memanggil tarik(double jumlah)

        // Memanggil method override 'tampilkanInformasiRekening'
        rekening2.tampilkanInformasiRekening();
    }
}
