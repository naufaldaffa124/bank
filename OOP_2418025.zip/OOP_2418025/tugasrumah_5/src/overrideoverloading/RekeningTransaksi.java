/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overrideoverloading;

/**
 *
 * @author 1242004
 */
import java.text.NumberFormat;
import java.util.Locale;

class RekeningTransaksi extends BankAccount {

    // Konstruktor: Memanggil konstruktor parent class
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal) {
        super(nomorRekening, namaPemilik, saldoAwal);
    }

    // Method Overloading: setor dengan satu parameter
    public void setor(double jumlah) {
        this.saldo += jumlah; // Menggunakan variabel protected langsung
        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        formatter.setMinimumFractionDigits(1);
        formatter.setMaximumFractionDigits(1);
        System.out.println("Berhasil menyetor: Rp" + formatter.format(jumlah));
    }

    // Method Overloading: setor dengan dua parameter (misal: untuk transfer dengan biaya)
    public void setor(double jumlah, double biayaTransfer) {
        if (this.saldo >= biayaTransfer) {
            this.saldo += (jumlah - biayaTransfer);
            NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
            formatter.setMinimumFractionDigits(1);
            formatter.setMaximumFractionDigits(1);
            System.out.println("Berhasil menyetor: Rp" + formatter.format(jumlah) + " (dipotong biaya transfer Rp" + formatter.format(biayaTransfer) + ")");
        } else {
            System.out.println("Saldo tidak mencukupi untuk biaya transfer.");
        }
    }

    // Method Overloading: tarik dengan satu parameter
    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah; // Menggunakan variabel protected langsung
            NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
            formatter.setMinimumFractionDigits(1);
            formatter.setMaximumFractionDigits(1);
            System.out.println("Berhasil menarik: Rp" + formatter.format(jumlah));
        } else {
            System.out.println("Saldo tidak mencukupi untuk penarikan Rp" + String.format("%,.1f", jumlah));
        }
    }

    // Method Overloading: tarik dengan dua parameter (misal: tarik tunai dengan biaya)
    public void tarik(double jumlah, double biayaPenarikan) {
        double totalPenarikan = jumlah + biayaPenarikan;
        if (this.saldo >= totalPenarikan) {
            this.saldo -= totalPenarikan;
            NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
            formatter.setMinimumFractionDigits(1);
            formatter.setMaximumFractionDigits(1);
            System.out.println("Berhasil menarik: Rp" + formatter.format(jumlah) + " (ditambah biaya penarikan Rp" + formatter.format(biayaPenarikan) + ")");
        } else {
            System.out.println("Saldo tidak mencukupi untuk penarikan Rp" + String.format("%,.1f", jumlah) + " dan biaya penarikan Rp" + String.format("%,.1f", biayaPenarikan));
        }
    }

    // Method Override: Mengganti implementasi tampilkanInformasiRekening dari parent
    @Override
    public void tampilkanInformasiRekening() {
        super.tampilkanInformasiRekening(); // Memanggil method parent
        // Bisa menambahkan informasi spesifik transaksi jika diperlukan, tapi untuk kasus ini, cukup panggil parent
    }
}