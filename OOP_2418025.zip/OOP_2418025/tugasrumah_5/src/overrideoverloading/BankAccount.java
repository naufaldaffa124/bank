/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package overrideoverloading;

/**
 *
 * @author 1242004
 */
import java.text.NumberFormat;
import java.util.Locale;

public class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo; 

    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }

    public String getNomorRekening() {
        return nomorRekening;
    }

    public String getNamaPemilik() {
        return namaPemilik;
    }

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldoBaru) {
        this.saldo = saldoBaru;
    }

    // Metode untuk menampilkan informasi rekening (akan di-override)
    public void tampilkanInformasiRekening() {
        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        formatter.setMinimumFractionDigits(1); // Set minimum 1 digit desimal
        formatter.setMaximumFractionDigits(1); // Set maximum 1 digit desimal

        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + getNomorRekening());
        System.out.println("Nama Pemilik   : " + getNamaPemilik());
        System.out.println("Saldo          : Rp" + formatter.format(getSaldo()));
    }
}

