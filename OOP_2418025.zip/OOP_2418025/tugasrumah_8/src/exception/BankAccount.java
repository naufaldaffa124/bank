package exception;
public class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;
    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }
    public String getNomorRekening() {
        return nomorRekening;
    }
    public String getNamaPemilik() {
        return namaPemilik;
    }
    public double getSaldo() {
        return saldo;
    }
    public void setor(double jumlah) {
        this.saldo += jumlah;
        System.out.println("Berhasil menyetor: Rp" + String.format("%,.0f", jumlah));
    }
    
    // Metode tarik yang akan dioverride dan mungkin melempar exception
    public void tarik(double jumlah) throws Exception {
        if (jumlah <= 0) {
            throw new IllegalArgumentException("Jumlah penarikan tidak boleh nol atau negatif.");
        }
        if (this.saldo < jumlah) {
            throw new Exception("Saldo tidak cukup untuk melakukan penarikan sebesar Rp" + String.format("%,.0f", jumlah) + ",0.");
        }
        this.saldo -= jumlah;
        System.out.println("Berhasil menarik: Rp" + String.format("%,.0f", jumlah));
    }

    public void tampilInformasi() {
        System.out.println("=== Informasi Rekening ===");
        System.out.println("Nomor Rekening : " + nomorRekening);
        System.out.println("Nama Pemilik   : " + namaPemilik);
        System.out.println("Saldo          : Rp" + String.format("%,.1f", saldo));
    }
}


