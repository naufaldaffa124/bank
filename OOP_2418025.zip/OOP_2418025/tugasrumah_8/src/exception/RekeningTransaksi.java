package exception;
public class RekeningTransaksi extends BankAccount {
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal) {
        super(nomorRekening, namaPemilik, saldoAwal);
    }
}
