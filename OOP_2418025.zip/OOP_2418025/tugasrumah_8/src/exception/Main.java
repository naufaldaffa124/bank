/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception;

/**
 *
 * @author 1242004
 */
public class Main {
    public static void main(String[] args) {
        // Contoh skenario pertama
        System.out.println("--- Skenario 1: Penarikan Berhasil ---");
        RekeningTransaksi rekening1 = new RekeningTransaksi("1234567890", "anonymous", 5000000.0); // Saldo awal Rp5.000.000
        rekening1.tampilInformasi();
        rekening1.setor(90000000.0); // Setor Rp90.000.000
        try {
            rekening1.tarik(2000000.0); // Tarik Rp2.000.000
        } catch (Exception e) {
            System.err.println("Error penarikan: " + e.getMessage());
        }
        System.out.println(); // Baris kosong untuk pemisah

        // Contoh skenario kedua
        System.out.println("--- Skenario 2: Penarikan Gagal (Saldo tidak cukup & Jumlah nol/negatif) ---");
        RekeningTransaksi rekening2 = new RekeningTransaksi("1234567890", "anonymous", 93000000.0); // Saldo awal Rp93.000.000 (sesuai hasil akhir skenario 1)
        rekening2.tampilInformasi();

        try {
            rekening2.tarik(100000000.0); // Tarik Rp100.000.000 (Saldo tidak cukup)
        } catch (Exception e) {
            System.err.println("Error penarikan: " + e.getMessage());
        }

        System.out.println("Nama Pemilik   : " + rekening2.getNamaPemilik()); // Tampilkan nama pemilik (sesuai contoh output)

        try {
            rekening2.tarik(0.0); // Tarik Rp0 (Jumlah nol/negatif)
        } catch (IllegalArgumentException e) { // Tangkap IllegalArgumentException secara spesifik
            System.err.println("Error penarikan: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error penarikan: " + e.getMessage());
        }

        System.out.println("Saldo          : Rp" + String.format("%,.1f", rekening2.getSaldo()));
    }
}
