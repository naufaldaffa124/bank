package interfaceclass;
public class Main {
    public static void main(String[] args) {
        // Rekening pertama
        RekeningTransaksi rekening1 = new RekeningTransaksi("1234567890", "anonymous", 5000000.0, 90000000.0, 2000000.0);
        rekening1.tampilkanInformasiRekening();
        rekening1.tampilkanInformasiTransaksi();

        System.out.println(); // Baris kosong untuk pemisah

        // Rekening kedua (simulasi update saldo)
        RekeningTransaksi rekening2 = new RekeningTransaksi("1234567890", "anonymous", 5000000.0, 0, 0); // Saldo awal dan transaksi 0
        rekening2.setor(90000000.0); // Simulasikan setoran
        rekening2.tarik(2000000.0);  // Simulasikan penarikan
        rekening2.tampilkanInformasiRekening(); // Saldo akan mencerminkan hasil setoran dan penarikan

        // Contoh untuk memastikan saldo benar setelah transaksi
        System.out.println();
        System.out.println("=== Simulasi Saldo Akhir ===");
        RekeningTransaksi rekeningFinal = new RekeningTransaksi("1234567890", "anonymous", 5000000.0, 0, 0);
        rekeningFinal.setor(90000000.0);
        rekeningFinal.tarik(2000000.0);
        rekeningFinal.tampilkanInformasiRekening(); // Menampilkan saldo akhir yang benar: 93.000.000,0
    }
}
