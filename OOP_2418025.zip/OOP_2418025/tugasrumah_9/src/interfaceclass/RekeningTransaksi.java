package interfaceclass;
public class RekeningTransaksi extends BankAccount implements InformasiTransaksi {
    private double totalSetor;
    private double totalTarik;
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal, double totalSetor, double totalTarik) {
        super(nomorRekening, namaPemilik, saldoAwal);
        this.totalSetor = totalSetor;
        this.totalTarik = totalTarik;
    }

    @Override
    public void tampilkanInformasiRekening() {
        System.out.println("=== Informasi Rekening ===");
        System.out.println("Nomor Rekening : " + nomorRekening);
        System.out.println("Nama Pemilik   : " + namaPemilik);
        System.out.println("Saldo          : Rp" + String.format("%.0f", saldo) + ",0");
    }

    @Override
    public void tampilkanInformasiTransaksi() {
        System.out.println("Berhasil menyetor: Rp" + String.format("%.0f", totalSetor) + ",0");
        System.out.println("Berhasil menarik: Rp" + String.format("%.0f", totalTarik) + ",0");
    }

    public void setor(double jumlah) {
        this.saldo += jumlah;
        this.totalSetor += jumlah;
    }

    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah;
            this.totalTarik += jumlah;
        } else {
            System.out.println("Saldo tidak mencukupi.");
        }
    }
}
