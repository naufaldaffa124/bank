package interfaceclass;
public abstract class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;

    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }

    // Metode abstrak yang harus diimplementasikan oleh subclass
    public abstract void tampilkanInformasiRekening();

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
}
