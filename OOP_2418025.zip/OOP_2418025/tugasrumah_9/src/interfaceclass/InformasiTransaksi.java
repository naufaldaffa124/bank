package interfaceclass;
public interface InformasiTransaksi {
    void tampilkanInformasiTransaksi();
}
