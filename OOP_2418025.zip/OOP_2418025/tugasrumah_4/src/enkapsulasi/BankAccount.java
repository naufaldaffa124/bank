/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author 1242004
 */
public class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;

    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }

    // enkapsulasi getter
    public String getNomorRekening() {
        return nomorRekening;
    }

    public String getNamaPemilik() {
        return namaPemilik;
    }

    public double getSaldo() {
        return saldo;
    }

    // enkapsulasi setter
    protected void setSaldo(double saldoBaru) {
        this.saldo = saldoBaru;
    }

    public void tampilkanInformasiRekening() {
        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + getNomorRekening());
        System.out.println("Nama Pemilik   : " + getNamaPemilik());
        System.out.println("Saldo          : Rp" + String.format("%,.1f", getSaldo()));
    }
}
