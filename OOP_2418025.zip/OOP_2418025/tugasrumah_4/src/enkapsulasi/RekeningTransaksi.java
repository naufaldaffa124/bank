/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enkapsulasi;

/**
 *
 * @author 1242004
 */
public class RekeningTransaksi extends BankAccount {
    // Konstruktor dari parent class akan dipanggil secara implisit atau eksplisit
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal) {
        super(nomorRekening, namaPemilik, saldoAwal); // Memanggil konstruktor parent class
    }

    public void setor(double jumlah) {
        setSaldo(getSaldo() + jumlah);
        System.out.println("Berhasil menyetor: Rp" + String.format("%,.1f", jumlah));
    }

    public void tarik(double jumlah) {
        if (getSaldo() >= jumlah) {
            setSaldo(getSaldo() - jumlah);
            System.out.println("Berhasil menarik: Rp" + String.format("%,.1f", jumlah));
        } else {
            System.out.println("Saldo tidak mencukupi untuk penarikan Rp" + String.format("%,.1f", jumlah));
        }
    }
}
