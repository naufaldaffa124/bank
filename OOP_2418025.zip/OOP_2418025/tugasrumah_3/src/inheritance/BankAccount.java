package inheritance;
public class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;

    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }
    public void setor(double jumlah) {
        this.saldo += jumlah;
        System.out.printf("Berhasil menyetor: Rp%,.1f%n", jumlah); // Menggunakan printf untuk format koma
    }
    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah;
            System.out.printf("Berhasil menarik: Rp%,.1f%n", jumlah); // Menggunakan printf untuk format koma
        } else {
            System.out.println("Saldo tidak cukup untuk menarik.");
        }
    }
    public void tampilkanInformasiDasarRekening() {
        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + this.nomorRekening);
        System.out.println("Nama Pemilik   : " + this.namaPemilik);
        System.out.printf("Saldo          : Rp%,.1f%n", this.saldo); // Menggunakan printf untuk format koma
    }
}

