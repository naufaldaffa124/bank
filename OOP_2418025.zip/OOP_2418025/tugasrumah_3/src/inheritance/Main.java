/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author 1242004
 */
public class Main {
    public static void main(String[] args) {
        RekeningBank rekeningNasabah = new RekeningBank("1234567890", "anonymous", 5000000.0);
        rekeningNasabah.tampilkanInformasiDasarRekening();
        rekeningNasabah.setor(1000000.0);
        rekeningNasabah.tarik(1000000.0);
        System.out.println(); 
        rekeningNasabah.tampilkanInformasiDasarRekening();
    }
}
