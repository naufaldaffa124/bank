package abstractclass;
public class Main {
    public static void main(String[] args) {
        RekeningTransaksi rekeningAwal = new RekeningTransaksi("1234567890", "anonymous", 5000000.0);
        rekeningAwal.tampilkanInformasiDasar();
        System.out.println();
        
        RekeningTransaksi rekeningTransaksi = new RekeningTransaksi("1234567890", "anonymous", 5000000.0);
        rekeningTransaksi.setor(10000000.0);
        rekeningTransaksi.tarik(2000000.0);
        rekeningTransaksi.tampilkanInformasiDasar();
    }
}
