package abstractclass;
import java.text.NumberFormat;
import java.util.Locale;

// (abstract class)
public abstract class BankAccount {
    protected String nomorRekening;
    protected String namaPemilik;
    protected double saldo;

    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }

    public String getNomorRekening() {
        return nomorRekening;
    }

    public String getNamaPemilik() {
        return namaPemilik;
    }

    public double getSaldo() {
        return saldo;
    }

    protected void setSaldo(double saldoBaru) {
        this.saldo = saldoBaru;
    }

    public void tampilkanInformasiDasar() {
        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        formatter.setMinimumFractionDigits(1);
        formatter.setMaximumFractionDigits(1);

        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + getNomorRekening());
        System.out.println("Nama Pemilik   : " + getNamaPemilik());
        System.out.println("Saldo          : Rp" + formatter.format(getSaldo()));
    }

    public abstract void setor(double jumlah);
    public abstract void tarik(double jumlah);
}

