package abstractclass;
import java.text.NumberFormat;
import java.util.Locale;

public class RekeningTransaksi extends BankAccount {
    public RekeningTransaksi(String nomorRekening, String namaPemilik, double saldoAwal) {
        super(nomorRekening, namaPemilik, saldoAwal);
    }
    @Override
    public void setor(double jumlah) {
        this.saldo += jumlah; // Menggunakan variabel protected langsung
        NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
        formatter.setMinimumFractionDigits(1);
        formatter.setMaximumFractionDigits(1);
        System.out.println("Berhasil menyetor: Rp" + formatter.format(jumlah));
    }
    @Override
    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah; // Menggunakan variabel protected langsung
            NumberFormat formatter = NumberFormat.getNumberInstance(new Locale("id", "ID"));
            formatter.setMinimumFractionDigits(1);
            formatter.setMaximumFractionDigits(1);
            System.out.println("Berhasil menarik: Rp" + formatter.format(jumlah));
        } else {
            System.out.println("Saldo tidak mencukupi untuk penarikan Rp" + String.format("%,.1f", jumlah));
        }
    }
}

