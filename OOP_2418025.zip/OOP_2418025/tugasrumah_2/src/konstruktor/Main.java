/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konstruktor;

/**
 *
 * @author 1242004
 */
public class Main {
    public static void main(String[] args) {
        BankAccount rekening1 = new BankAccount("1234567890", "anonymous", 5000000.0);
        rekening1.tampilkanInformasiRekening();

        rekening1.setor(1000000.0);
        rekening1.tarik(1000000.0);

        System.out.println("\n==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + rekening1.nomorRekening);
        System.out.println("Nama Pemilik   : " + rekening1.namaPemilik);
        System.out.println("Saldo          : Rp" + String.format("%.1f", rekening1.saldo));
    }
}
