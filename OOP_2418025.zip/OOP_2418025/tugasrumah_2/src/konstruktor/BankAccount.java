/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package konstruktor;

/**
 *
 * @author 1242004
 */
public class BankAccount {
    String nomorRekening;
    String namaPemilik;
    double saldo;

    // (Method konstruktor)
    public BankAccount(String nomorRekening, String namaPemilik, double saldoAwal) {
        this.nomorRekening = nomorRekening;
        this.namaPemilik = namaPemilik;
        this.saldo = saldoAwal;
    }

    public void setor(double jumlah) {
        this.saldo += jumlah;
        System.out.println("Berhasil menyetor: Rp" + String.format("%.1f", jumlah));
    }

    public void tarik(double jumlah) {
        if (this.saldo >= jumlah) {
            this.saldo -= jumlah;
            System.out.println("Berhasil menarik: Rp" + String.format("%.1f", jumlah));
        } else {
            System.out.println("Saldo tidak cukup untuk menarik: Rp" + String.format("%.1f", jumlah));
        }
    }

    public void tampilkanInformasiRekening() {
        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + this.nomorRekening);
        System.out.println("Nama Pemilik   : " + this.namaPemilik);
        System.out.println("Saldo          : Rp" + String.format("%.1f", this.saldo));
    }
}
