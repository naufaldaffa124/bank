/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccount;
public class Main {
    public static void main(String[] args) {
        BankAccount myAccount = new BankAccount("1234567890", "anonymous", 5000000);
        myAccount.displayAccountInfo();
        myAccount.deposit(1500000);
        myAccount.withdraw(2000000);
        myAccount.displayAccountInfo();
    }
}
