package bankaccount;
public class BankAccount {
    String accountNumber;
    String accountHolder;
    double balance;

    public BankAccount(String accountNumber, String accountHolder, double initialBalance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = initialBalance;
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Berhasil menyetor: Rp" + amount);
        } else {
            System.out.println("Jumlah setoran harus lebih dari 0.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Berhasil menarik: Rp" + amount);
        } else {
            System.out.println("Penarikan gagal. Saldo tidak mencukupi atau jumlah tidak valid.");
        }
    }

    public void displayAccountInfo() {
        System.out.println("==== Informasi Rekening ====");
        System.out.println("Nomor Rekening : " + accountNumber);
        System.out.println("Nama Pemilik   : " + accountHolder);
        System.out.println("Saldo          : Rp" + balance);
    }
}

